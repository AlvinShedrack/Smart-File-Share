
from flask import Flask
import os

app = Flask(__name__)

@app.route('/')
def home():
    return """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Traverse Templates</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f4f9;
            text-align: center;
            padding: 50px;
        }
        h2 {
            color: #333;
        }
        .button-container {
            margin-top: 30px;
        }
        .template-button {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 12px 24px;
            margin: 10px;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
        .template-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Open Traverse Computation Templates</h2>
    <div class="button-container">
        <a href="/open/4" class="template-button">4</a>
        <a href="/open/5" class="template-button">5</a>
        <a href="/open/6" class="template-button">6</a>
        <a href="/open/7" class="template-button">7</a>
        <a href="/open/8" class="template-button">8</a>
    </div>
</body>
</html>
"""

@app.route('/open/<int:num>')
def open_file(num):
    file_path = fr"D:\CADASTRAL\Templates\{num}.xls"
    if os.path.exists(file_path):
        os.startfile(file_path)
        return f"Opened file: {file_path}"
    else:
        return f"File not found: {file_path}", 404

if __name__ == '__main__':
    app.run(debug=True)
